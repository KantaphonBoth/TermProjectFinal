
LICENSE:

This template released under the Creative Commons Attribution-NoDerivatives 4.0 International License ( https://creativecommons.org/licenses/by-nd/4.0/ ) This means that you are free:

	Share — copy and redistribute the material in any medium or format
	for any purpose, even commercially.
	
	Under the following terms:

	Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.

	NoDerivatives — If you remix, transform, or build upon the material, you may not distribute the modified material.
	
	You must include a credit link to our website( https://awaikenthemes.com ) somewhere on
	your site. We like the footer credit that comes with the template. But you can also move to another place.
	

For removing our credit link: Read more here - https://awaikenthemes.com/license


These Terms of Service or license are subject to change at any time, without prior notice. 

====================================================================


SOURCES AND CREDITS:

Fonts:
	https://fonts.google.com/

Icons:
	http://fontawesome.io/
	https://www.flaticon.com/
	https://linearicons.com/free
	http://themes-pixeden.com/font-demos/7-stroke/

Stock Photos and Graphics:
	https://unsplash.com/
	https://www.freepik.com/
	https://pixabay.com/
 
Javascript Files:

	http://jquery.com/
	http://modernizr.com/
	http://imakewebthings.com/jquery-waypoints/
	https://owlcarousel2.github.io/OwlCarousel2/
	https://github.com/alicelieutier/smoothScroll
	http://dimsemenov.com/plugins/magnific-popup/



====================================================================


Thanks for downloading from https://awaikenthemes.com
